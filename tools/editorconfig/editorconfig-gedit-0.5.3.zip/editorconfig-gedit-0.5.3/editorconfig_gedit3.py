from editorconfig_plugin.gedit3 import *
