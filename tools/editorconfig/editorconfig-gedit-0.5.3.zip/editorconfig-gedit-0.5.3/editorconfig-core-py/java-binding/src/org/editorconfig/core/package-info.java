/**
 * Provides the Java API for accessing 
 * <a href="http://editorconfig.org">EditorConfig</a> Core
 * (For the purpose and usage of EditorConfig, see
 * <a href="http://editorconfig.org">EditorConfig</a> homepage for details).
 */

package org.editorconfig.core;
