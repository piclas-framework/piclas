from editorconfig_plugin.gedit2 import *
